有使用到numpy和opencv
code是在win11底下執行的


Package       Version
------------- ---------
numpy         1.26.4
opencv-python 4.10.0.82
pip           24.0
setuptools    65.5.0