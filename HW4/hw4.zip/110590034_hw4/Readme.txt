有使用到numpy和opencv
code是在win11底下執行的


Package       Version
------------- --------
numpy         1.26.4
opencv-python 4.9.0.80
pip           22.2.2
setuptools    63.2.0